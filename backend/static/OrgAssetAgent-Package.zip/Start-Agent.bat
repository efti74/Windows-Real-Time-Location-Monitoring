@echo off
set "SCRIPT_DIR=%~dp0"
set "EXE_PATH=%SCRIPT_DIR%OrgAssetAgent.exe"

:: 1. Check if the user ran directly inside the ZIP without extracting
if not exist "%EXE_PATH%" (
    echo ====================================================================
    echo [ERROR] OrgAssetAgent.exe not found!
    echo.
    echo Please EXTRACT the zip file before running:
    echo   1. Right-click the downloaded OrgAssetAgent-Package.zip
    echo   2. Click "Extract All..."
    echo   3. Open the newly extracted folder and double-click Start-Agent.bat
    echo ====================================================================
    echo.
    pause
    exit /b 1
)

:: 2. Ensure Administrator privileges so Windows Location Service can be configured
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 3. Change working directory to the folder containing the executable
cd /d "%SCRIPT_DIR%"

:: 4. Force-enable Windows Location Service and unblock binary
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' -Recurse -Force -ErrorAction SilentlyContinue; " ^
    "Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Recurse -Force -ErrorAction SilentlyContinue; " ^
    "Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\LocationAndSensors' -Recurse -Force -ErrorAction SilentlyContinue; " ^
    "Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc' -Name 'Start' -Value 2 -Type DWord -ErrorAction SilentlyContinue; " ^
    "Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration' -Name 'Status' -Value 1 -Type DWord -ErrorAction SilentlyContinue; " ^
    "$cp = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location\NonPackaged', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location\NonPackaged'); " ^
    "foreach ($c in $cp) { if (-not (Test-Path $c)) { New-Item -Path $c -Force | Out-Null }; Set-ItemProperty -Path $c -Name 'Value' -Value 'Allow' -Type String -ErrorAction SilentlyContinue }; " ^
    "if (Test-Path \"$env:WINDIR\System32\SystemSettingsAdminFlows.exe\") { Start-Process \"$env:WINDIR\System32\SystemSettingsAdminFlows.exe\" -ArgumentList 'SetCamSystemGlobal location 1' -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue }; " ^
    "Set-Service Lfsvc -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service Lfsvc -ErrorAction SilentlyContinue; " ^
    "Unblock-File -LiteralPath '%EXE_PATH%' -ErrorAction SilentlyContinue"

:: 5. Launch the executable with its full absolute path
start "" "%EXE_PATH%"
